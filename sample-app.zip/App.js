import React from 'react';
import { StyleSheet, Text, View, ListView, FlatList } from 'react-native';
import Odoo from 'react-native-odoo';


export default class App extends React.Component {
  constructor(props) {   
    super(props);    

    this.state = {    
      loading: false,    
      data: [],        
      error: null,    
      refreshing: false    
    };    

    this.status = new Date().toString(); 
    this.custs = [];
    this.test = 'test';
  }
  

  componentWillMount() {    
    console.log('mounted');
    this.getData();    
  }

  
  getData() {
    this.status = new Date().toString();

    let configs = {
        odoo_server: 'http://35.197.28.1:8069',
        http_auth: 'basic_auth_user:basic_auth_pass'
    };
    
    const odoo = new Odoo({
      host: '35.197.28.1',
      port: 8069,
      database: 'test',
      username: 'admin',
      password: 'zaq12wsx'
    });

    odoo.connect(function (err) {
      if (err) { return console.log(err); }
    });

    var params = {
      domain: [ ['customer', '=', 'true']],
      fields: [ 'name', 'city', 'mobile', 'id'],
      limit: 20,
      offset: 0,  
    }; 

    odoo.search_read('res.partner', params, function (err, customers) {
      if (err) { return console.log(err); }
     
      this.custs = customers;
      console.log(this.custs[0].name);
      this.test = 'test1';
    });

  }
  

  render() {       
    return (
      <View style={styles.container}>
        <Text>{this.test}</Text>
        <FlatList>
          data={[{key: 'a'}, {key: 'b'}]}
          renderItem={({item}) => <Text>{item.key}</Text>}
        </FlatList>
        <Text>{this.status}</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
